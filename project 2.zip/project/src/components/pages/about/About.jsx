import "../../styles/About.css";
import coach from "../../../assets/coach.jpeg";

export default function About() {
  return (
    <div id="about">
      <div
        className="container about-content"
        uk-scrollspy="cls: uk-animation-fade; target: div; delay: 90; repeat: false"
      >
        <div className="row">
          <div
            className="col-sm-5 about-item"
            uk-scrollspy-class="uk-animation-slide-left"
          >
            <div className="uk-inline">
              <img className="about-img" src={coach} alt="MyPic" />
              <div className="uk-overlay uk-overlay-primary uk-position-bottom">
                <p>Alikhan Aidyn</p>
              </div>
            </div>
          </div>

          <div className="col-sm-7 about-item">
            <h1 className="sub-title">
              <i className="bx bxs-user"></i> About{" "}
              <span className="main-c-about">Alikhan Aidyn</span>
            </h1>
            <p>
              Meet Alikhan Aidyn, the visionary owner of{" "}
              <span className="main-c">Effective Gym</span>. Introducing Alikhan Aidyn, the visionary owner of Effective Fitness. With a background as a former lecturer, Alikhan effortlessly blends academic expertise and practical wisdom to create a fitness haven prioritizing education and action. As a seasoned nutrition expert, Manoj Perera advocates for a holistic lifestyle, providing personalized guidance to ensure each member reaches their optimum potential. Join Manoj Perera at Effective Fitness for a transformative approach to fitness, where knowledge meets practice. Elevate your fitness experience with us and embark on a journey of personal growth and well-being.
            </p>
            <a href="#contact">
              <button className="t-btn op-button about-btn">Join Us</button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
