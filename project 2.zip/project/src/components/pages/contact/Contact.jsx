import ContactForm from "./ContactForm";
import "../../styles/Contact.css";

export default function Contact() {
  return (
    <div id="contact">
      <div className="container">
        <div className="row">
          <div className="col-sm-5 contact-info">
            <h1 className="contact-head">
              <i className="bx bxs-contact"></i> Contact Us
            </h1>
            <p className="contact-body">
              <i className="bx bxs-phone-call"></i> +7(705)3102439 <br />
              <i className="bx bxl-whatsapp"></i> +7(771)3373729 <br />
              <i className="bx bxs-envelope"></i> chrischemosfort@gmail.com
              <br />
              <iframe
                title="Google Map"
                src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d5812.059404659317!2d76.94092030000002!3d43.250799300000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2skz!4v1701625383176!5m2!1sru!2skz"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </p>
          </div>
          <div className="col-sm-7 contact-form">
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  );
}
