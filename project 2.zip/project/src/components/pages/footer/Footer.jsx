import "../../styles/Footer.css";

export default function Footer() {
  return (
    <div id="footer">
      <footer>
        <div className="container">
          <hr />
          <div className="row">
            <div className="col text-start footer-small">
              <p>
                Made with{" "}
                <span>
                  <i className="bx bxs-heart" />
                </span>{" "}
                <br /> by{" "}
                <a
                  href="https://github.com/Aidyn000"
                  className="footer-link main-c"
                >
                  Alikhan Aidyn
                </a>
              </p>
            </div>
            <div className="col text-start footer-large">
              <p>
                © Alikhan Aidyn <br /> Designed &
                Developed by{" "}
                <a
                  href="https://github.com/Aidyn000"
                  className="footer-link main-c"
                >
                  @ALzFIRDAUS
                </a>
              </p>
            </div>

            <div className="col text-end footer-socials">
              <a href="https://youtu.be/c3qKzMkj2IM?si=HvMuy8GLIPa-myno">
              <i className="bx bxl-facebook-square footer-socials-icon"></i>{" "}

              </a>
              <i className="bx bxl-instagram-alt footer-socials-icon"></i>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
