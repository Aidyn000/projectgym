import React, { useState } from "react";
import "../../styles/Cart.css"; // Import your CSS file

export default function Cart() {
    const [cartItems, setCartItems] = useState([]);
    const [formData, setFormData] = useState({
        itemName: "",
        quantity: 0,
    });
    const [editingIndex, setEditingIndex] = useState(null);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (editingIndex !== null) {
            // If editing, update the cartItems array
            const updatedCartItems = [...cartItems];
            updatedCartItems[editingIndex] = { ...formData };
            setCartItems(updatedCartItems);
            setEditingIndex(null);
        } else {
            // If not editing, add a new item to the cartItems array
            setCartItems((prevItems) => [...prevItems, formData]);
        }

        // Clear the form inputs
        setFormData({ itemName: "", quantity: 0 });
    };

    const handleEdit = (index) => {
        setFormData(cartItems[index]);
        setEditingIndex(index);
    };

    const handleDelete = (index) => {
        const updatedCartItems = [...cartItems];
        updatedCartItems.splice(index, 1);
        setCartItems(updatedCartItems);
    };

    return (
        <div className="container-cart">

            {/* CRUD Form */}
            <form onSubmit={handleSubmit}>
                <label>
                    Pass name:
                    <input
                        type="text"
                        name="itemName"
                        value={formData.itemName}
                        onChange={handleInputChange}
                    />
                </label>
                <label>
                    Quantity:
                    <input
                        type="number"
                        name="quantity"
                        value={formData.quantity}
                        onChange={handleInputChange}
                    />
                </label>
                <button type="submit" className="cart-btn">
                    {editingIndex !== null ? "Update" : "Add"}
                </button>
            </form>

            {/* Display cart items with Edit and Delete buttons */}
            <ul>
                {cartItems.map((item, index) => (
                    <li key={index} className="cart-item">
                        <strong>{item.itemName}</strong>: {item.quantity} units{" "}
                        <button onClick={() => handleEdit(index)} className="edit-btn">
                            Edit
                        </button>{" "}
                        <button onClick={() => handleDelete(index)} className="delete-btn">
                            Delete
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
}
